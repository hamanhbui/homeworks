# domain-generalization
A code base with AGG for DG, reproduced results of https://github.com/HAHA-DL/Episodic-DG with full torch.
### Guideline
To prepare: (download, extract then move to same this directory)
- Dataset: https://drive.google.com/file/d/1fciyuI8gjYczfRJH2gBNoFQ8KyCDDNn7/view?usp=sharing
- Pretrained models: https://drive.google.com/file/d/11SE5NrwFbEAsGYre7eYwyGKEfTIcemFJ/view?usp=sharing

To train model: (results are stored in results/)
- bash run.sh

python main.py --config "algorithms/AGG/configs/PACS_art.json"
tensorboard --logdir=/home/ubuntu/domain-generalization/algorithms/AGG/results/tensorboards/PACS_sketch